package packagepar;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.Color;
//import java.text.SimpleDateFormat;
//import java.util.Date;

public class Espacio {
    private final JButton[] botones;
    private int BotonLibre;
    private int BotonOcupado;
    private final Registro[] registros;
    

    
    public Espacio(JButton[] botones) {
        this.botones = botones;
        this.BotonLibre = 0; // Inicia desde el primer botón
        this.BotonOcupado = -1; 
        this.registros = new Registro [botones.length];  
      //  HoraActual();
        agregarActionListeners();
    }
   /* private void HoraActual() {
        SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm");
        String THora = formatoHora.format(new Date());
      
    }*/
    private void agregarActionListeners() {
        for (int i = 0; i < botones.length; i++) {
            final int index = i;
            botones[i].addActionListener(e -> VerInfo(index));
        }
    }

    private void VerInfo(int index) {
        Registro registro = registros[index];
        if (registro != null) {
            String mensaje = "Placa: " + registro.getPlaca() + "\n"
                           + "Tipo vehículo: " + registro.getTipo() + "\n"
                           + "Cédula: " + registro.getCedula() + "\n";
                        //   + "Hora de Entrada: " + registro.getHoraActual();
            JOptionPane.showMessageDialog(null, mensaje, "Información del Espacio", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Este espacio está libre.", "", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void manejarIngreso(Registro registro) {
        if (BotonLibre < botones.length) {
            JButton boton = botones[BotonLibre];
            registros[BotonLibre] = registro; // Guarda el registro
            boton.setBackground(Color.red); 
            boton.setText("ocupado"); 
            
            BotonLibre++; // siguiente
        } else {
            JOptionPane.showMessageDialog(null, "No hay más espacios libres.");
        }
    }
    public void manejarSalida() {
        if (BotonOcupado >=0) { 
            JButton boton = botones[BotonOcupado];
            boton.setBackground(Color.green);     
            BotonOcupado--; 
            
        } else {
            JOptionPane.showMessageDialog(null, "Todos los espacios están libres.");
        }     
        
   
    } 
  
    
         
}