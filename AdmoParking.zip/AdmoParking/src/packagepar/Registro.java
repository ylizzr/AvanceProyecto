package packagepar;

public class Registro {
    private String cedula;
    private String placa;
    private String tipo;
    
    

    public Registro(String cedula, String placa, String tipo) {
        this.cedula = cedula;
        this.placa = placa;
        this.tipo = tipo;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }
    
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

   

   

    
}
